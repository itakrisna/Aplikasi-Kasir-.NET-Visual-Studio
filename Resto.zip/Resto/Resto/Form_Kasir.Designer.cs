﻿namespace Resto
{
    partial class Form_Kasir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            numericUpDown_jumlah = new NumericUpDown();
            label_jumlah_uang = new Label();
            textBox_jumlah_uang = new TextBox();
            textBox_total_harga = new TextBox();
            button_tambah = new Button();
            textBox_no_wa_pembeli = new TextBox();
            textBox_nama_pembeli = new TextBox();
            label_no_wa_pembeli = new Label();
            label_nama_pembeli = new Label();
            label_harga = new Label();
            label_jumlah = new Label();
            label_menu = new Label();
            textBox_harga = new TextBox();
            comboBox_menu = new ComboBox();
            dataGridView_bill = new DataGridView();
            Column_menu = new DataGridViewTextBoxColumn();
            Column_jumlah = new DataGridViewTextBoxColumn();
            Column_harga = new DataGridViewTextBoxColumn();
            Column_total_harga = new DataGridViewTextBoxColumn();
            Column_nama_pembeli = new DataGridViewTextBoxColumn();
            Column__no_wa_pembeli = new DataGridViewTextBoxColumn();
            label_total_harga = new Label();
            button_jumlah_kembalian = new Button();
            textBox_jumlah_kembalian = new TextBox();
            button_hapus = new Button();
            button_kembali = new Button();
            button_next_from = new Button();
            button_print_bill = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_jumlah).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_bill).BeginInit();
            SuspendLayout();
            // 
            // numericUpDown_jumlah
            // 
            numericUpDown_jumlah.Location = new Point(116, 392);
            numericUpDown_jumlah.Name = "numericUpDown_jumlah";
            numericUpDown_jumlah.Size = new Size(150, 27);
            numericUpDown_jumlah.TabIndex = 42;
            // 
            // label_jumlah_uang
            // 
            label_jumlah_uang.AutoSize = true;
            label_jumlah_uang.Location = new Point(486, 388);
            label_jumlah_uang.Name = "label_jumlah_uang";
            label_jumlah_uang.Size = new Size(94, 20);
            label_jumlah_uang.TabIndex = 36;
            label_jumlah_uang.Text = "Jumlah Uang";
            // 
            // textBox_jumlah_uang
            // 
            textBox_jumlah_uang.Location = new Point(633, 381);
            textBox_jumlah_uang.Name = "textBox_jumlah_uang";
            textBox_jumlah_uang.Size = new Size(151, 27);
            textBox_jumlah_uang.TabIndex = 35;
            // 
            // textBox_total_harga
            // 
            textBox_total_harga.Location = new Point(633, 348);
            textBox_total_harga.Name = "textBox_total_harga";
            textBox_total_harga.Size = new Size(151, 27);
            textBox_total_harga.TabIndex = 34;
            // 
            // button_tambah
            // 
            button_tambah.BackColor = SystemColors.ActiveBorder;
            button_tambah.Location = new Point(273, 349);
            button_tambah.Name = "button_tambah";
            button_tambah.Size = new Size(94, 28);
            button_tambah.TabIndex = 33;
            button_tambah.Text = "Tambah";
            button_tambah.UseVisualStyleBackColor = false;
            button_tambah.Click += button_tambah_Click;
            // 
            // textBox_no_wa_pembeli
            // 
            textBox_no_wa_pembeli.Location = new Point(486, 18);
            textBox_no_wa_pembeli.Name = "textBox_no_wa_pembeli";
            textBox_no_wa_pembeli.Size = new Size(151, 27);
            textBox_no_wa_pembeli.TabIndex = 32;
            // 
            // textBox_nama_pembeli
            // 
            textBox_nama_pembeli.Location = new Point(177, 18);
            textBox_nama_pembeli.Name = "textBox_nama_pembeli";
            textBox_nama_pembeli.Size = new Size(151, 27);
            textBox_nama_pembeli.TabIndex = 31;
            // 
            // label_no_wa_pembeli
            // 
            label_no_wa_pembeli.AutoSize = true;
            label_no_wa_pembeli.Location = new Point(339, 25);
            label_no_wa_pembeli.Name = "label_no_wa_pembeli";
            label_no_wa_pembeli.Size = new Size(113, 20);
            label_no_wa_pembeli.TabIndex = 30;
            label_no_wa_pembeli.Text = "No WA Pembeli";
            // 
            // label_nama_pembeli
            // 
            label_nama_pembeli.AutoSize = true;
            label_nama_pembeli.Location = new Point(30, 25);
            label_nama_pembeli.Name = "label_nama_pembeli";
            label_nama_pembeli.Size = new Size(106, 20);
            label_nama_pembeli.TabIndex = 29;
            label_nama_pembeli.Text = "Nama Pembeli";
            // 
            // label_harga
            // 
            label_harga.AutoSize = true;
            label_harga.Location = new Point(14, 432);
            label_harga.Name = "label_harga";
            label_harga.Size = new Size(50, 20);
            label_harga.TabIndex = 28;
            label_harga.Text = "Harga";
            // 
            // label_jumlah
            // 
            label_jumlah.AutoSize = true;
            label_jumlah.Location = new Point(18, 399);
            label_jumlah.Name = "label_jumlah";
            label_jumlah.Size = new Size(55, 20);
            label_jumlah.TabIndex = 27;
            label_jumlah.Text = "Jumlah";
            // 
            // label_menu
            // 
            label_menu.AutoSize = true;
            label_menu.Location = new Point(18, 358);
            label_menu.Name = "label_menu";
            label_menu.Size = new Size(46, 20);
            label_menu.TabIndex = 26;
            label_menu.Text = "Menu";
            // 
            // textBox_harga
            // 
            textBox_harga.Location = new Point(116, 425);
            textBox_harga.Name = "textBox_harga";
            textBox_harga.Size = new Size(151, 27);
            textBox_harga.TabIndex = 25;
            // 
            // comboBox_menu
            // 
            comboBox_menu.FormattingEnabled = true;
            comboBox_menu.Location = new Point(116, 350);
            comboBox_menu.Name = "comboBox_menu";
            comboBox_menu.Size = new Size(151, 28);
            comboBox_menu.TabIndex = 24;
            comboBox_menu.Text = "Pilih Menu";
            // 
            // dataGridView_bill
            // 
            dataGridView_bill.BackgroundColor = SystemColors.ControlLightLight;
            dataGridView_bill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_bill.Columns.AddRange(new DataGridViewColumn[] { Column_menu, Column_jumlah, Column_harga, Column_total_harga, Column_nama_pembeli, Column__no_wa_pembeli });
            dataGridView_bill.Location = new Point(18, 64);
            dataGridView_bill.Name = "dataGridView_bill";
            dataGridView_bill.RowHeadersWidth = 51;
            dataGridView_bill.RowTemplate.Height = 29;
            dataGridView_bill.Size = new Size(881, 256);
            dataGridView_bill.TabIndex = 45;
            // 
            // Column_menu
            // 
            Column_menu.HeaderText = "Pesanan";
            Column_menu.MinimumWidth = 6;
            Column_menu.Name = "Column_menu";
            Column_menu.Width = 250;
            // 
            // Column_jumlah
            // 
            Column_jumlah.HeaderText = "Jumlah";
            Column_jumlah.MinimumWidth = 6;
            Column_jumlah.Name = "Column_jumlah";
            Column_jumlah.Width = 250;
            // 
            // Column_harga
            // 
            Column_harga.HeaderText = "Harga";
            Column_harga.MinimumWidth = 6;
            Column_harga.Name = "Column_harga";
            Column_harga.Width = 200;
            // 
            // Column_total_harga
            // 
            Column_total_harga.HeaderText = "Total Harga";
            Column_total_harga.MinimumWidth = 6;
            Column_total_harga.Name = "Column_total_harga";
            Column_total_harga.Width = 125;
            // 
            // Column_nama_pembeli
            // 
            Column_nama_pembeli.HeaderText = "Nama Pembeli";
            Column_nama_pembeli.MinimumWidth = 6;
            Column_nama_pembeli.Name = "Column_nama_pembeli";
            Column_nama_pembeli.Width = 125;
            // 
            // Column__no_wa_pembeli
            // 
            Column__no_wa_pembeli.HeaderText = "No WA";
            Column__no_wa_pembeli.MinimumWidth = 6;
            Column__no_wa_pembeli.Name = "Column__no_wa_pembeli";
            Column__no_wa_pembeli.Width = 125;
            // 
            // label_total_harga
            // 
            label_total_harga.AutoSize = true;
            label_total_harga.Location = new Point(488, 353);
            label_total_harga.Name = "label_total_harga";
            label_total_harga.Size = new Size(87, 20);
            label_total_harga.TabIndex = 46;
            label_total_harga.Text = "Total Harga";
            // 
            // button_jumlah_kembalian
            // 
            button_jumlah_kembalian.BackColor = SystemColors.ActiveBorder;
            button_jumlah_kembalian.Location = new Point(486, 423);
            button_jumlah_kembalian.Name = "button_jumlah_kembalian";
            button_jumlah_kembalian.Size = new Size(139, 29);
            button_jumlah_kembalian.TabIndex = 48;
            button_jumlah_kembalian.Text = "Jumlah Kembalian";
            button_jumlah_kembalian.UseVisualStyleBackColor = false;
            button_jumlah_kembalian.Click += button_jumlah_kembalian_Click;
            // 
            // textBox_jumlah_kembalian
            // 
            textBox_jumlah_kembalian.Location = new Point(633, 425);
            textBox_jumlah_kembalian.Name = "textBox_jumlah_kembalian";
            textBox_jumlah_kembalian.Size = new Size(151, 27);
            textBox_jumlah_kembalian.TabIndex = 47;
            // 
            // button_hapus
            // 
            button_hapus.BackColor = SystemColors.ActiveBorder;
            button_hapus.Location = new Point(272, 388);
            button_hapus.Name = "button_hapus";
            button_hapus.Size = new Size(94, 28);
            button_hapus.TabIndex = 52;
            button_hapus.Text = "Hapus";
            button_hapus.UseVisualStyleBackColor = false;
            button_hapus.Click += button_hapus_Click;
            // 
            // button_kembali
            // 
            button_kembali.BackColor = SystemColors.ActiveBorder;
            button_kembali.Location = new Point(801, 428);
            button_kembali.Name = "button_kembali";
            button_kembali.Size = new Size(94, 28);
            button_kembali.TabIndex = 53;
            button_kembali.Text = "Kembali";
            button_kembali.UseVisualStyleBackColor = false;
            button_kembali.Click += button_kembali_Click;
            // 
            // button_next_from
            // 
            button_next_from.BackColor = SystemColors.ActiveBorder;
            button_next_from.Location = new Point(801, 390);
            button_next_from.Name = "button_next_from";
            button_next_from.Size = new Size(94, 28);
            button_next_from.TabIndex = 54;
            button_next_from.Text = "Next Form";
            button_next_from.UseVisualStyleBackColor = false;
            button_next_from.Click += button_next_from_Click;
            // 
            // button_print_bill
            // 
            button_print_bill.BackColor = SystemColors.ActiveBorder;
            button_print_bill.Location = new Point(801, 347);
            button_print_bill.Name = "button_print_bill";
            button_print_bill.Size = new Size(94, 28);
            button_print_bill.TabIndex = 55;
            button_print_bill.Text = "Print Bill";
            button_print_bill.UseVisualStyleBackColor = false;
            button_print_bill.Click += button_print_bill_Click;
            // 
            // Form_Kasir
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(927, 485);
            Controls.Add(button_print_bill);
            Controls.Add(button_next_from);
            Controls.Add(button_kembali);
            Controls.Add(button_hapus);
            Controls.Add(button_jumlah_kembalian);
            Controls.Add(textBox_jumlah_kembalian);
            Controls.Add(label_total_harga);
            Controls.Add(dataGridView_bill);
            Controls.Add(numericUpDown_jumlah);
            Controls.Add(label_jumlah_uang);
            Controls.Add(textBox_jumlah_uang);
            Controls.Add(textBox_total_harga);
            Controls.Add(button_tambah);
            Controls.Add(textBox_no_wa_pembeli);
            Controls.Add(textBox_nama_pembeli);
            Controls.Add(label_no_wa_pembeli);
            Controls.Add(label_nama_pembeli);
            Controls.Add(label_harga);
            Controls.Add(label_jumlah);
            Controls.Add(label_menu);
            Controls.Add(textBox_harga);
            Controls.Add(comboBox_menu);
            Name = "Form_Kasir";
            Text = "Form_Kasir";
            ((System.ComponentModel.ISupportInitialize)numericUpDown_jumlah).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_bill).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NumericUpDown numericUpDown_jumlah;
        private Label label_jumlah_uang;
        private TextBox textBox_jumlah_uang;
        private TextBox textBox_total_harga;
        private Button button_tambah;
        private TextBox textBox_no_wa_pembeli;
        private TextBox textBox_nama_pembeli;
        private Label label_no_wa_pembeli;
        private Label label_nama_pembeli;
        private Label label_harga;
        private Label label_jumlah;
        private Label label_menu;
        private TextBox textBox_harga;
        private ComboBox comboBox_menu;
        private DataGridView dataGridView_bill;
        private Label label_total_harga;
        private Button button_jumlah_kembalian;
        private TextBox textBox_jumlah_kembalian;
        private DataGridViewTextBoxColumn Column_menu;
        private DataGridViewTextBoxColumn Column_jumlah;
        private DataGridViewTextBoxColumn Column_harga;
        private DataGridViewTextBoxColumn Column_total_harga;
        private DataGridViewTextBoxColumn Column_nama_pembeli;
        private DataGridViewTextBoxColumn Column__no_wa_pembeli;
        private Button button_hapus;
        private Button button_kembali;
        private Button button_next_from;
        private Button button_print_bill;
    }
}