﻿namespace Resto
{
    partial class Form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_nama = new Label();
            label_password = new Label();
            textBox_nama = new TextBox();
            textBox_password = new TextBox();
            button_login = new Button();
            SuspendLayout();
            // 
            // label_nama
            // 
            label_nama.AutoSize = true;
            label_nama.Location = new Point(214, 164);
            label_nama.Name = "label_nama";
            label_nama.Size = new Size(49, 20);
            label_nama.TabIndex = 0;
            label_nama.Text = "Nama";
            // 
            // label_password
            // 
            label_password.AutoSize = true;
            label_password.Location = new Point(214, 230);
            label_password.Name = "label_password";
            label_password.Size = new Size(70, 20);
            label_password.TabIndex = 1;
            label_password.Text = "Password";
            // 
            // textBox_nama
            // 
            textBox_nama.Location = new Point(340, 157);
            textBox_nama.Name = "textBox_nama";
            textBox_nama.Size = new Size(343, 27);
            textBox_nama.TabIndex = 2;
            // 
            // textBox_password
            // 
            textBox_password.Location = new Point(340, 223);
            textBox_password.Name = "textBox_password";
            textBox_password.Size = new Size(343, 27);
            textBox_password.TabIndex = 3;
            // 
            // button_login
            // 
            button_login.Location = new Point(546, 310);
            button_login.Name = "button_login";
            button_login.Size = new Size(94, 29);
            button_login.TabIndex = 4;
            button_login.Text = "Login";
            button_login.UseVisualStyleBackColor = true;
            button_login.Click += button_login_Click;
            // 
            // Form_Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(927, 485);
            Controls.Add(button_login);
            Controls.Add(textBox_password);
            Controls.Add(textBox_nama);
            Controls.Add(label_password);
            Controls.Add(label_nama);
            Name = "Form_Login";
            Text = "Form_Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_nama;
        private Label label_password;
        private TextBox textBox_nama;
        private TextBox textBox_password;
        private Button button_login;
    }
}