﻿namespace Resto
{
    partial class Form_Pesanan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_kirim = new Button();
            dataGridView_pesanan = new DataGridView();
            button_kembali = new Button();
            button_data_pesanan = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView_pesanan).BeginInit();
            SuspendLayout();
            // 
            // button_kirim
            // 
            button_kirim.BackColor = SystemColors.ActiveBorder;
            button_kirim.Location = new Point(387, 435);
            button_kirim.Name = "button_kirim";
            button_kirim.Size = new Size(142, 28);
            button_kirim.TabIndex = 34;
            button_kirim.Text = "Kirim";
            button_kirim.UseVisualStyleBackColor = false;
            button_kirim.Click += button_kirim_Click;
            // 
            // dataGridView_pesanan
            // 
            dataGridView_pesanan.BackgroundColor = SystemColors.ControlLightLight;
            dataGridView_pesanan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_pesanan.Location = new Point(12, 24);
            dataGridView_pesanan.Name = "dataGridView_pesanan";
            dataGridView_pesanan.RowHeadersWidth = 51;
            dataGridView_pesanan.RowTemplate.Height = 29;
            dataGridView_pesanan.Size = new Size(903, 391);
            dataGridView_pesanan.TabIndex = 29;
            // 
            // button_kembali
            // 
            button_kembali.BackColor = SystemColors.ActiveBorder;
            button_kembali.Location = new Point(559, 435);
            button_kembali.Name = "button_kembali";
            button_kembali.Size = new Size(142, 28);
            button_kembali.TabIndex = 54;
            button_kembali.Text = "Kembali";
            button_kembali.UseVisualStyleBackColor = false;
            button_kembali.Click += button_kembali_Click;
            // 
            // button_data_pesanan
            // 
            button_data_pesanan.BackColor = SystemColors.ActiveBorder;
            button_data_pesanan.Location = new Point(218, 435);
            button_data_pesanan.Name = "button_data_pesanan";
            button_data_pesanan.Size = new Size(142, 28);
            button_data_pesanan.TabIndex = 56;
            button_data_pesanan.Text = "Data Pesanan";
            button_data_pesanan.UseVisualStyleBackColor = false;
            button_data_pesanan.Click += button_data_pesanan_Click;
            // 
            // Form_Pesanan
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(927, 485);
            Controls.Add(button_data_pesanan);
            Controls.Add(button_kembali);
            Controls.Add(button_kirim);
            Controls.Add(dataGridView_pesanan);
            Name = "Form_Pesanan";
            Text = "Form_Pesanan";
            ((System.ComponentModel.ISupportInitialize)dataGridView_pesanan).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button_kirim;
        private TextBox textBox_message;
        private Label label_message;
        private DataGridView dataGridView_pesanan;
        private Button button_kembali;
        private Button button_data_pesanan;
    }
}